<?php
if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
/**
 * 在所需的区域输出IP属地信息
 *
 * @package IP属地显示
 * @author 苏晓晴
 * @version 1.3
 * @link https://www.toubiec.cn/
 */
 
/* https://github.com/itbdw/ip-database */
require_once dirname(__FILE__) . '/ipdata/src/IpLocation.php';
require_once dirname(__FILE__) . '/ipdata/src/ipdbv6.func.php';
use itbdw\Ip\IpLocation;
/* https://github.com/itbdw/ip-database */

require_once dirname(__FILE__) . '/ip2region/src/XdbSearcher.php';
use ip2region\XdbSearcher;

class XQLocation_Plugin extends Typecho_Widget implements Typecho_Plugin_Interface {
    /**
     * 激活插件方法，如果激活失败，直接抛出异常
     *
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate() {
        // 激活插件时的操作
        Typecho_Plugin::factory('Widget_Feedback')->finishComment = [__CLASS__, 'changeIP']; //前台评论提交
        Typecho_Plugin::factory('Widget_Comments_Edit')->finishComment = [__CLASS__, 'changeIP']; //后台评论提交
        return _t('插件已启用!');
     }

    /**
     * 禁用插件方法，如果禁用失败，直接抛出异常
     *
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate() {}

    /**
     * 获取插件配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form) {
        /* IP属地信息 显示开关 */
        $LocationButton = new Typecho_Widget_Helper_Form_Element_Select('LocationButton', array(
            'on' => '开启（默认）',
            'off' => '关闭',
        ),"on",_t("IP属地信息 显示开关"),'介绍：开启后，将激活插件并在插入代码之后显示IP属地信息');
        $form->addInput($LocationButton->multiMode());
        
        /* 是否显示图标 */
        $icon = new Typecho_Widget_Helper_Form_Element_Radio(
            'icon', 
            array('off' => _t('不显示(默认)'),'on'=>_t('显示')),
            'off','设置 图标 显示','介绍：开启后，将会在IP属地信息前面加个图标显示(如果发现主题不适配 可以选择不显示)');
        $form->addInput($icon);
        
        /* IPV4数据库选择 */
        $ipv4db = new Typecho_Widget_Helper_Form_Element_Radio(
            'ipv4db', 
            array('ip2region' => _t('ip2region数据库'),'cz88'=>_t('纯真数据库')),
            'cz88','IPV4数据库选项','介绍：此项是选择IPV4类型的数据库！');
        $form->addInput($ipv4db);

        $ipSource = new Typecho_Widget_Helper_Form_Element_Select(
            'ipSource',
            array(
                'REMOTE_ADDR' => 'REMOTE_ADDR (默认)',
                'HTTP_CLIENT_IP' => 'HTTP_CLIENT_IP',
                'HTTP_X_REAL_IP' => 'HTTP_X_REAL_IP',
                'HTTP_X_FORWARDED_FOR' => 'HTTP_X_FORWARDED_FOR'
            ),
            'REMOTE_ADDR', // 默认值
            _t('选择获取 IP 的来源'),
            _t('介绍：此项是选择IP的来源<br>如果加了CDN可以选HTTP_X_FORWARDED_FOR 没有加CDN就默认即可')
        );
        $form->addInput($ipSource);
    }

    /**
     * 个人用户的配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form) {}

    /**
     * 插件实现方法
     *
     * @access public
     * @return void
     */
    public static function render($ip) {
        $options = Typecho_Widget::widget('Widget_Options');
        $data = Helper::options()->plugin('XQLocation');
        if ($data->LocationButton === "on"){
           $msgip = self::img_ico($data->icon === "on").self::convertip($ip);
           echo $msgip;
        }
    }

    /** 图标显示 */
    public static function img_ico($type){
        if($type){
          return '<img class="icon-ua" src="'.Helper::options()->pluginUrl . '/XQLocation/img/dingwei.svg'.'" height="14" style="vertical-align:-2px;">';            
        }
    }
    
    // 修改评论的 IP 值
    public static function changeIP($comment)
    {
        $options = Typecho_Widget::widget('Widget_Options');
        $data = Helper::options()->plugin('XQLocation');
        // 设置获取到源IP的选项
        if($data->ipSource === 'HTTP_CLIENT_IP'){
            $ip = $_SERVER['HTTP_CLIENT_IP'];    
        }elseif($data->ipSource === 'HTTP_X_REAL_IP'){
            $ip = $_SERVER['HTTP_X_REAL_IP'];    
        }elseif($data->ipSource === 'HTTP_X_FORWARDED_FOR'){
            if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
                $ip = trim($ipList[0]);
            }
        }else{
            $ip = $_SERVER['REMOTE_ADDR'];    
        }
        $db = Typecho_Db::get();
        if (!empty($ip)) {
            // 更新到数据库
            $db->query($db->update('table.comments')
                ->rows(array('ip' => $ip))
                ->where('coid = ?', $comment->coid)
            );
        }
        return $comment;
    }

    /** 获取评论者归属地信息 */
    public static function convertip($ip){
    if (!filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_IPV6)) {
        if(Helper::options()->plugin('XQLocation')->ipv4db === "cz88"){
	       $ipaddr = IpLocation::getLocation($ip)['area'];
           //修改获取方式
           $ipaddr = str_replace(['数据中心','数据上网公共出口','(全省通用)'], '', $ipaddr);
           //修改获取方式
           $ipaddr = str_replace(['局域网IP'], '火星地区', $ipaddr);   
        }else{
           $xdb = __DIR__ . DIRECTORY_SEPARATOR . 'ip2region/src/ip2region.xdb';
           $region = XdbSearcher::newWithFileOnly($xdb)->search($ip);
           $region = str_replace("0", "", $region);

           // 将字符串转换为数组
           $subStrings = explode(' ', $region);

           $repeatedSubstring = explode('|', $region)[3];
           $newString = '';

           foreach ($subStrings as $subString) {
               if (strpos($newString, $subString) !== false) {
                   $repeatedSubstring = $subString;
                   break;
               }
               $newString .= $subString . ' ';
           }

           if ($repeatedSubstring) {
               $newString = str_replace($repeatedSubstring, '', $newString);
               $ipaddr = str_replace("|", "", $newString); // 输出: 中国北京市腾讯
           } else {
               $ipaddr = str_replace("|", "", $region); // 没有重复子串，输出原字符串
           }
        $ipaddr = $ipaddr;
        }
    } else {
	    $ipaddr = self::ipquery($ip);
    }
        return $ipaddr;
    }
    
    /** 获取评论者归属地信息 */    
    public static function ipquery($ip) {
	$db6 = new ipdbv6(__DIR__ . DIRECTORY_SEPARATOR . 'ipdata/src/zxipv6wry.db');
	$code = 0;
	try {
		if (filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_IPV6)) {
			$result = $db6->query($ip);
		}
	}
	catch (Exception $e) {
		$result = array("disp" => $e->getMessage());
		$code = -400;
	}
	$o1 = $result["addr"][0];
	$o2 = $result["addr"][1];
	$o1 = str_replace("\"", "\\\"", $o1);
	$o2 = str_replace("\"", "\\\"", $o2);
	$local = str_replace(["无线基站网络","公众宽带","3GNET网络","CMNET网络","CTNET网络","\t"],"",$o1);
	$locals = str_replace(["无线基站网络","公众宽带","3GNET网络","CMNET网络","CTNET网络","中国","\t"],"",$o2);
	return $local.$locals;
}
}
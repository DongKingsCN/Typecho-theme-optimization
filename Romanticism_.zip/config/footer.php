<?php
/**
    _    _  __    _    ____  _    _ ___ 
   / \  | |/ /   / \  / ___|| | | |_ _|
  / _ \ | ' /   / _ \ \___ \| |_| || | 
 / ___ \| . \   / ___ \ ___) |  _  || | 
/_/   \_\_|\_\/_/   \_\____/|_| |_|___|

 * [Romanticism]
 * footer.php 页脚文件
 * @version 2.2 - 250710
**/
?>

<div class="mdui-shadow-0 mdui-text-center mdui-card toup">
<br>

      <br>
      <span class="title">
        &copy;<?php echo date("Y"); ?> <?php $this->options->title(); ?>
        <br>
        <!-- 本站运行时间展示 -->
        <span id="sitetime" style="font-size: 13px; opacity: 0.8;">本站已勉强运行 0 天 0 小时 0 分 0 秒</span>
      </span>
      <br>

<!-- 纯本地全站访客统计紫色小方格 -->
      <div style="text-align: center; margin: 8px 0; font-size: 12px; font-family: sans-serif;">
        <span style="display: inline-block; border-radius: 4px; overflow: hidden; box-shadow: 0 1px 2px rgba(0,0,0,0.2);">
          <span style="background-color: #6A5ACD; color: #FFFFFF; padding: 3px 8px; display: inline-block;">你是本站第</span>
          <span style="background-color: #836FFF; color: #FFFFFF; padding: 3px 8px; display: inline-block; font-weight: bold;">
            <?php
            // 原生轻量级本地计数器
            $counter_file = __DIR__ . '/site_visitors.txt';
            // 如果文件不存在，初始化为你想要的起始数字（比如 14）
            if (!file_exists($counter_file)) {
                file_put_contents($counter_file, '14');
            }
            $visitors = (int)file_get_contents($counter_file);
            // 使用 Cookie 防止单次会话疯狂刷新 F5 刷浏览量（有效期 1 小时）
            if (!isset($_COOKIE['site_visited'])) {
                $visitors++;
                file_put_contents($counter_file, $visitors);
                setcookie('site_visited', '1', time() + 3600, '/');
            }
            echo $visitors;
            ?> 位访客
          </span>
        </span>
      </div>

      <?php if($this->options->AKAROMfootericp):?>
          <?php echo $this->options->AKAROMfootericp; ?>
      <?php endif;?>
      
      <br>
      <!-- 已经弄得很不显眼了，请不要删除以下信息 -->
      <br><br>
    </div>

    <!-- 运行时间计算 JS -->
    <script>
    function siteTime() {
        window.setTimeout("siteTime()", 1000);
        var seconds = 1000;
        var minutes = seconds * 60;
        var hours = minutes * 60;
        var days = hours * 24;
        
        // 【关键】请修改为你的建站精确时间 (格式：年/月/日 时:分:秒)
        var createTime = new Date("2026/03/15 00:00:00"); 
        var today = new Date();
        var diff = today - createTime;
        
        var diffDays = Math.floor(diff / days);
        var diffHours = Math.floor((diff % days) / hours);
        var diffMinutes = Math.floor((diff % hours) / minutes);
        var diffSeconds = Math.floor((diff % minutes) / seconds);
        
        var siteTimeSpan = document.getElementById("sitetime");
        if (siteTimeSpan) {
            siteTimeSpan.innerHTML = "本站已勉强运行 " + diffDays + " 天 " + diffHours + " 小时 " + diffMinutes + " 分 " + diffSeconds + " 秒";
        }
    }
    siteTime();
    </script>

    <script>
        document.getElementById("switch-theme").addEventListener("click", () => {
            const isDark = document.body.classList.toggle("mdui-theme-layout-dark");
            if(isDark){
                localStorage.romanticismTheme = true;
            }else{
                delete localStorage.romanticismTheme;
            }
        });
    </script>

    <script src="<?php $this->options->themeUrl('config/mdui/js/mdui.min.js'); ?>"></script>
    <script src="<?php $this->options->themeUrl('config/js/jquery.min.js'); ?>"></script>
    
    <script src="<?php $this->options->themeUrl('config/js/listLazyload.js?v=2.2'); ?>"></script>
    <script src="<?php $this->options->themeUrl('config/js/tagIcon.js?v=2.2'); ?>"></script>
    <script src="<?php $this->options->themeUrl('config/js/customStyle.js?v=2.2'); ?>"></script>
    <script src="<?php $this->options->themeUrl('config/js/returntop.js?v=2.2'); ?>"></script>
    <script src="<?php $this->options->themeUrl('config/js/prism.highlight.js'); ?>"></script>

    <script src="<?php $this->options->themeUrl('config/js/jquery.fancybox.min.js'); ?>"></script>
    <script>
        $(document).ready(function () {
            $( ".fancybox").fancybox();
        });
    </script>

    <?php if (!empty($this->options->AKAROMfucset) && in_array('AKAROMindexloading', $this->options->AKAROMfucset)): ?>
    <script type="text/javascript" src="<?php $this->options->themeUrl('config/js/loading.js?v=2.2'); ?>"></script>
    <?php endif; ?>
    
    <script src="<?php $this->options->themeUrl('config/js/OwO.js'); ?>"></script>
    <script>
    function OwO_show() {
        if ($(".OwO-items").css("max-height") == '0px') {
            $(".OwO").addClass("OwO-open");
        } else {
            $(".OwO").removeClass("OwO-open");
        }
    }
    </script>

    <script src="<?php $this->options->themeUrl('config/js/md5.min.js'); ?>"></script>
    <script src="<?php $this->options->themeUrl('config/js/preheadicon.js?v=2.2'); ?>"></script>

    <!-- 自定义JS -->
    <?php if(!empty($this->options->AKAROMcustomJs)): ?>
        <script type="text/javascript">
            <?php $this->options->AKAROMcustomJs(); ?>
        </script>
    <?php endif; ?>

    <?php $this->footer(); ?>
</div>
</body>
</html>